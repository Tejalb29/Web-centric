<?php
$filePath = 'booking.xml';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking-id'])) {
    $bookingIdToEdit = $_POST['booking-id'];

    // Load the XML file
    if (file_exists($filePath)) {
        $xml = simplexml_load_file($filePath);

        // Find the booking to edit
        foreach ($xml->booking as $booking) {
            if ($booking->{'booking-id'} == $bookingIdToEdit) {
                // Pre-fill form with booking data
                $bookingToEdit = $booking;
                break;
            }
        }

        if (!isset($bookingToEdit)) {
            echo "Booking not found!";
            exit;
        }
    }
} else {
    echo "Invalid request!";
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

        <!--stylesheet-->
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  
        <!--Javascript for the navbar-->
        <script src="main.js" ></script>
        <title>Edit Booking</title>
    </head>

    <body>

     <!--Navbar-->
    <nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="home.php" class="logo">
            <div class="animated-word">
                <img src="logo.png" style="height: 35px;">
                <div class="letter">L</div>
                <div class="letter">u</div>
                <div class="letter">z</div>
                <div class="letter">a</div>
                <div class="letter">F</div>
                <div class="letter">l</div>
                <div class="letter">y</div>
            </div>
        </a>
            
        <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->

    </ul>

        
        <i class="uil uil-search search-icon" id="searchIcon"></i>
        <div class="search-box">
            <i class="uil uil-search search-icon"></i>
            <input type="text" placeholder="Search here..." />
        </div>
    </nav>
    <!--End of navbar-->
<br>
<br>
<br>
<br>


    <h1 class="text-center mb-4">Edit Booking</h1>
    <div class="booking-form">
    <div class="container">
    <form action="update_booking.php" method="post" class="row g-3">
        <input type="hidden" name="booking-id" value="<?php echo $bookingToEdit->{'booking-id'}; ?>">
        
        <!-- First Name -->
        <div class="col-md-6">
            <label for="first-name" class="form-label">First Name</label>
            <input type="text" class="form-control" id="first-name" name="first-name" value="<?php echo $bookingToEdit->{'first_name'}; ?>" required>
        </div>

        <!-- Last Name -->
        <div class="col-md-6">
            <label for="last-name" class="form-label">Last Name</label>
            <input type="text" class="form-control" id="last-name" name="last-name" value="<?php echo $bookingToEdit->{'last_name'}; ?>" required>
        </div>

        <!-- ID Number -->
        <div class="col-md-6">
            <label for="id-number" class="form-label">ID Number</label>
            <input type="text" class="form-control" id="id-number" name="id-number" value="<?php echo $bookingToEdit->{'id_number'}; ?>" required>
        </div>

        <!-- To Location -->
        <div class="col-md-6">
            <label for="to-location" class="form-label">To Location</label>
            <input type="text" class="form-control" id="to-location" name="to-location" value="<?php echo $bookingToEdit->{'to_location'}; ?>" required>
        </div>

        <!-- Departure Date -->
        <div class="col-md-6">
            <label for="departure-date" class="form-label">Departure Date</label>
            <input type="date" class="form-control" id="departure-date" name="departure-date" value="<?php echo $bookingToEdit->{'departure_date'}; ?>" required>
        </div>

        <!-- Return Date -->
        <div class="col-md-6">
            <label for="return-date" class="form-label">Return Date</label>
            <input type="date" class="form-control" id="return-date" name="return-date" value="<?php echo $bookingToEdit->{'return_date'}; ?>" required>
        </div>

        <!-- Class -->
        <div class="col-md-6">
            <label for="class" class="form-label">Class</label>
            <input type="text" class="form-control" id="class" name="class" value="<?php echo $bookingToEdit->{'class'}; ?>" required>
        </div>

        <!-- Submit Button -->
        <div class="col-12 text-center">
            <button type="submit" class="bttn" style="width: 30%;">Update Booking</button>
        </div>
    </form>
</div>
</div>
<style>
/* Styling for the booking-form element */
.booking-form {
  flex: 1;
  backdrop-filter: blur(20px);
  max-width: 670px; /* Increased width */
  margin-bottom: 350px;
  padding: 20px;
  border: 2px solid #ccc;
  border-radius: 50px;
  margin: auto; /* Centers the form horizontally */
}
body {
            background-image: url("cloudbackground.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
          }
</style>
</body>
</html>
