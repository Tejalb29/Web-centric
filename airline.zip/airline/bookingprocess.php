<?php
include("dbconnect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // AJAX WITH XML: Load the existing XML file containing flight information
    $xml = simplexml_load_file('booking.xml');

    // Retrieve form data (PHP with XML)
    $first_name = $_POST['first-name'];
    $last_name = $_POST['last-name'];
    $ID_Number = $_POST['id-number'];
    $travelling_to = $_POST['to-location'];
    $departure_date = $_POST['departure-date'];
    $return_date = $_POST['return-date'];
    $airline_class = $_POST['class'];
    $card_type = $_POST['card-type'];
    $card_num = $_POST['card-number'];
    $csv = $_POST['csv'];
    $expiry_month = $_POST['expiry-month'];
    $expiry_year = $_POST['expiry-year'];

    // Calculate number of days staying (PHP with XML)
    $departure = new DateTime($departure_date);
    $return = new DateTime($return_date);
    $interval = $departure->diff($return);
    $num_days_staying = $interval->days;

    // Calculate total price based on class and location (PHP with XML)
    $price_per_day = 0;

    // Economy class (PHP with XML)
    if ($airline_class === 'economy') {
        switch ($travelling_to) {
            case 'Istanbul, Turkey':
                $price_per_day = 446;
                break;
            case 'Tokyo, Japan':
                $price_per_day = 620;
                break;
            case 'Valencia, Spain':
                $price_per_day = 390;
                break;
            case 'Nordland, Norway':
                $price_per_day = 440;
                break;
            case 'Marrakech, Morocco':
                $price_per_day = 385;
                break;
            case 'Palawan Island, Philippines':
                $price_per_day = 335;
                break;
            case 'Dubai, United Arab Emirates':
                $price_per_day = 740;
                break;
            case 'Santorini, Greece':
                $price_per_day = 776;
                break;
            case 'Seoul, Korea':
                $price_per_day = 790;
                break;
            case 'Samarkand, Uzbekistan':
                $price_per_day = 375;
                break;
            case 'Paris, France':
                $price_per_day = 560;
                break;
            case 'Yamaguchi, Japan':
                $price_per_day = 940;
                break;
        }
    } 
    // Business class (PHP with XML)
    else if ($airline_class === 'business') {
        switch ($travelling_to) {
            case 'Istanbul, Turkey':
                $price_per_day = 600;
                break;
            case 'Tokyo, Japan':
                $price_per_day = 850;
                break;
            case 'Valencia, Spain':
                $price_per_day = 505;
                break;
            case 'Nordland, Norway':
                $price_per_day = 750;
                break;
            case 'Marrakech, Morocco':
                $price_per_day = 670;
                break;
            case 'Palawan Island, Philippines':
                $price_per_day = 570;
                break;
            case 'Dubai, United Arab Emirates':
                $price_per_day = 1570;
                break;
            case 'Santorini, Greece':
                $price_per_day = 1090;
                break;
            case 'Seoul, Korea':
                $price_per_day = 1180;
                break;
            case 'Samarkand, Uzbekistan':
                $price_per_day = 610;
                break;
            case 'Paris, France':
                $price_per_day = 840;
                break;
            case 'Yamaguchi, Japan':
                $price_per_day = 1350;
                break;
        }
    } 
    // First class (PHP with XML)
    else if ($airline_class === 'first-class') {
        switch ($travelling_to) {
            case 'Istanbul, Turkey':
                $price_per_day = 950;
                break;
            case 'Tokyo, Japan':
                $price_per_day = 1000;
                break;
            case 'Valencia, Spain':
                $price_per_day = 810;
                break;
            case 'Nordland, Norway':
                $price_per_day = 1100;
                break;
            case 'Marrakech, Morocco':
                $price_per_day = 1050;
                break;
            case 'Palawan Island, Philippines':
                $price_per_day = 980;
                break;
            case 'Dubai, United Arab Emirates':
                $price_per_day = 2200;
                break;
            case 'Santorini, Greece':
                $price_per_day = 1500;
                break;
            case 'Seoul, Korea':
                $price_per_day = 1755;
                break;
            case 'Samarkand, Uzbekistan':
                $price_per_day = 890;
                break;
            case 'Paris, France':
                $price_per_day = 1210;
                break;
            case 'Yamaguchi, Japan':
                $price_per_day = 1990;
                break;
        }
    }

    // Calculating total price (PHP with XML)
    $total_price = $price_per_day * $num_days_staying;

    
    // Check if any of the required fields are empty (PHP with XML)
    if (empty($first_name) || empty($last_name) || empty($ID_Number) || empty($travelling_to) || empty($departure_date) || empty($return_date) || empty($airline_class) || empty($card_type) || empty($card_num) || empty($csv) || empty($expiry_month) || empty($expiry_year)) {
        // If any required field is empty, return error response (AJAX with XML)
        $response = array('success' => false, 'message' => 'Please fill in all required fields!!!');
        echo json_encode($response);
        exit; // Stop further execution
    }

    // SQL query (PHP with XML)
    $sql = "INSERT INTO Bookings (first_name, last_name, ID_Number, travelling_to, departure_date, return_date, airline_class, card_type, card_num, csv, expiry_month, expiry_year, total_price) VALUES ('$first_name', '$last_name', '$ID_Number', '$travelling_to', '$departure_date', '$return_date', '$airline_class', '$card_type', '$card_num', '$csv', '$expiry_month', '$expiry_year', '$total_price')";

    if ($conn->query($sql) === TRUE) {

        // Generate a unique booking ID
        $bookingID = 'BK' . uniqid();

        // DOM with XML: Create a new booking element in the XML structure
        $newBooking = $xml->addChild('booking');

        // Add the unique booking ID
        $newBooking->addChild('booking-id', $bookingID);
        $newBooking->addChild('first_name', $first_name);  // First name
        $newBooking->addChild('last_name', $last_name);    // Last name
        $newBooking->addChild('id_number', $ID_Number);    // ID number
        $newBooking->addChild('to_location', $travelling_to);  // Destination location
        $newBooking->addChild('departure_date', $departure_date);  // Departure date
        $newBooking->addChild('return_date', $return_date);  // Return date
        $newBooking->addChild('class', $airline_class);  // Class (e.g., economy, business)

        // Add passenger details (DOM with XML)
        $passenger = $newBooking->addChild('passenger');
        $passenger->addChild('first_name', htmlspecialchars($first_name));
        $passenger->addChild('last_name', htmlspecialchars($last_name));
        $passenger->addChild('id_number', htmlspecialchars($ID_Number));

        // Add travel details (DOM with XML)
        $travel = $newBooking->addChild('travel');
        $travel->addChild('to_location', htmlspecialchars($travelling_to));
        $travel->addChild('departure_date', htmlspecialchars($departure_date));
        $travel->addChild('return_date', htmlspecialchars($return_date));
        $travel->addChild('class', htmlspecialchars($airline_class));

        // Add payment details (DOM with XML)
        $payment = $newBooking->addChild('payment');
        $payment->addChild('card_type', htmlspecialchars($card_type));
        $payment->addChild('card_number', htmlspecialchars($card_num));
        $payment->addChild('csv', htmlspecialchars($csv));
        $payment->addChild('expiry_month', htmlspecialchars($expiry_month));
        $payment->addChild('expiry_year', htmlspecialchars($expiry_year));

        // Add total price to the XML (DOM with XML)
        $travel->addChild('total_price', htmlspecialchars($total_price));

        // Save the updated XML data back to the 'booking.xml' file (DOM with XML)
        $xml->asXML('booking.xml');

        // AJAX with XML: Display a confirmation message upon successful save
        $response = array('success' => true, 'message' => 'Booking successful', 'bookingID' => $bookingID, 'first_name' => $first_name, 'last_name' => $last_name, 'travelling_to' => $travelling_to, 'num_days_staying' => $num_days_staying, 'total_price' => $total_price);
        echo json_encode($response);

    } else {
        // If there was an error with the query, return error response (AJAX with XML)
        $response = array('success' => false, 'message' => 'Error: ' . $sql . "<br>" . $conn->error);
        echo json_encode($response);
    }
}
?>
