<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login/Register</title>
  <link rel="stylesheet" href="login.css">
  <link rel="stylesheet" href="style.css">

  <!-- Unicons CSS -->
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!-- Main JavaScript file -->
  <script src="main.js" defer></script>

  <!-- Include jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!-- JavaScript for form submission -->
  <script src="login.js" defer></script>
</head>
<body> 
  <!-- Navigation bar -->
  <nav class="nav">
    <!-- Logo and navigation links -->
    <a href="home.php" class="logo">
      <!-- Animated logo -->
      <div class="animated-word">
        <img src="logo.png" style="height: 35px;">
        <div class="letter">L</div>
        <div class="letter">u</div>
        <div class="letter">z</div>
        <div class="letter">a</div>
        <div class="letter">F</div>
        <div class="letter">l</div>
        <div class="letter">y</div>
      </div>
    </a>
    <!-- Navigation links -->
    <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->
    </ul>
    <!-- Search icon and box -->
    <i class="uil uil-search search-icon" id="searchIcon"></i>
    <div class="search-box">
      <i class="uil uil-search search-icon"></i>
      <input type="text" placeholder="Search here..." />
    </div>
  </nav>

  <!-- Background image -->
  <div class="bgimg"></div>
  
  <!-- Main content container -->
  <div class="container">
    <!-- Content -->
    <div class="contents">
      <!-- Logo -->
      <img src="logo.png" style="height: 110px; width:110px; margin-left: -50px; margin-top: -50px;">
      <!-- Welcome message -->
      <div class="logtext">
        <h2>Welcome To Luzafly!<br><span>Ready to fly with us?</span></h2>
        <p>Login or Register to stay connected.</p>
      </div>
    </div>

    <!-- Login/Register box -->
    <div class="logreg-box">
      <!-- Login form -->
      <div class="form-box login">
        <form action="loginprocess.php" method="POST" onsubmit ="validateLoginForm();">
        <h2>Login</h2>
          <!-- Email input -->
        <div class= "input-box">
          <span class="icon">
            <ion-icon name="mail"></ion-icon>
          </span>
          <input type = "email" id="email" name="email"> 
          <label>Email</label>
        </div>
        <!-- Password input -->
        <div class="input-box">
          <span class="icon">
              <ion-icon name="lock-closed"></ion-icon>
          </span>
          <input type="password" id="password" name="password">
          <label>Password</label>
        </div>
        <!-- Remember Me checkbox and Forgot Password link -->
        <div class = "remember-forgot">
          <label><input type="checkbox">Remember Me</label>
          <a href= "#">Forgot Password?</a>
        </div>
        <!-- Login button -->
        <button type="submit" class="btn" name="submit">Log in</button>
        <!-- Login/Register switch -->
        <div class="login-register">
          <p>Don't have an account? <a href="#" class="register-link">Register</a></p>
        </div>
        </form>
      </div>

      <!-- Registration form -->
      <div class="form-box register">
        <form action="registerprocess.php" method="POST">
          <h2>Registration</h2>
        <!-- Username input -->
        <div class= "input-box">
          <span class="icon">
            <ion-icon name="person"></ion-icon>
          </span>
          <input type = "username" id="username" name="username" required> 
          <label>Username</label>
        </div>
        <!-- Email input -->
        <div class= "input-box">
          <span class="icon">
          <ion-icon name="mail"></ion-icon>
          </span>
          <input type = "email" id="email" name="email" required> 
          <label>Email</label>
        </div>
        <!-- Password input -->
        <div class="input-box">
          <span class="icon">
          <ion-icon name="lock-closed"></ion-icon>
          </span>
          <input type="password" id="password" name="password" required>
          <label>Password</label>
        </div>
        <!-- Terms & Conditions checkbox -->
        <div class = "remember-forgot">
          <label for> <input type="checkbox" required>I agree to the terms & conditions</label>
        </div>
        <!-- Register button -->
        <button type="submit" name="submit" class="btn">Register</button>
        <!-- Login/Register switch -->
        <div class="login-register">
          <p>Already have an account? <a href="#" class="login-link">Login</a></p>
        </div>
        </form>
      </div>
    </div>
  </div>

  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

  <footer style="bottom: -400px;">
    <div class="footer-container">
      <div class="left box">
        <h3>Our Info</h3>
        <div class="footer-content">
          <div class="place">
            <a href="https://maps.app.goo.gl/ejazZCHjVSguPEW89"><span class="bx bxs-map"></span></a>
            <span class="text">Address: Vacoas, Plaines Wilhems, Mauritius</span>
          </div>
          <div class="phone">
            <a href="tel:+23057461432"><span class="bx bxs-phone"></span></a>
            <span class="text">Phone: +230 5746 1432</span>
          </div>

          <div class="email">
            <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank"><span class="bx bxs-envelope"></span></a>
            <span class="text">Email: luzafly@gmail.com</span>
          </div>

          <div class="social">
            <a href="https://www.facebook.com"><span class="bx bxl-facebook"></span></a>
            <a href="https://www.x.com"><span class="bx bxl-twitter"></span></a>
            <a href="https://www.instagram.com"><span class="bx bxl-instagram"></span></a>
            <a href="https://www.linkedin.com"><span class="bx bxl-linkedin"></span></a>
          </div>
        </div>
      </div>

      <div class="center box">
        <h3>Quick Links</h3>
        <div class="footer-content">
          <ul class="linkslist">
            <li><a href="home.php">Home</a></li>
            <li><a href="discover.php">Discover</a></li>
            <li><a href="booking.php">Booking</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="login.php">Log In</a></li>
          </ul>
        </div>
      </div>

      <div class="right box">
        <h3>Contact Us</h3>
        <div class="footer-content">
          <form action="contact.php" method="post">
            <div class="email">
              <div class="text">Email *</div>
              <input type="email" name ="email" required>
            </div>
            <div class="msg">
              <div class="text">Message *</div>
              <textarea rows="2" cols="25" name="message" required></textarea>
            </div>
            <button type="submit" class="bttn">Send</button>
          </form>
        </div> 
      </div>
    </div>

    <div class="bottom">
      <center>
        <span class="credit">&copy; 2023 LuzaFly. All rights reserved.</span>
      </center>
    </div>
  </footer>

  <?php
    if (isset($_GET['message'])) {
      $message = $_GET['message'];
      echo "<script>alert('$message');</script>";
    }
  ?>

</body>
</html>