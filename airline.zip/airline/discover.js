
'use strict';
var activeIndex = 0; // Current active index of the carousel
var limit = 0; // Limit of the carousel controls
var disabled = false; // Flag to indicate if carousel transitions are disabled
var $stage = undefined; // jQuery object for the carousel stage
var $controls = undefined; // jQuery object for the carousel stage
var canvas = false; // Flag to indicate if canvas is used
var SPIN_FORWARD_CLASS = 'js-spin-fwd';
var SPIN_BACKWARD_CLASS = 'js-spin-bwd';
var DISABLE_TRANSITIONS_CLASS = 'js-transitions-disabled';
var SPIN_DUR = 1000; // Duration of carousel spinning animation

// Function to append carousel controls
var appendControls = function appendControls() {
       // Loop through the limit to append control elements
    for (var i = 0; i < limit; i++) {
        $('.carousel__control').append('<a href="#" data-index="' + i + '"></a>');
    }
    // Calculate height based on the last control element
    var height = $('.carousel__control').children().last().outerHeight();
     // Set the height of the carousel control container
    $('.carousel__control').css('height', 30 + limit * height);
    // Set $controls to refer to the carousel control elements
    $controls = $('.carousel__control').children();
    // Add 'active' class to the current active control element
    $controls.eq(activeIndex).addClass('active');
};

var setIndexes = function setIndexes() {
    // Loop through each child element of the '.spinner' container
    $('.spinner').children().each(function (i, el) {
        // Set the 'data-index' attribute of each element to its index
        $(el).attr('data-index', i);
        // Increment the 'limit' variable to keep track of the number of elements
        limit++;
    });
};

var duplicateSpinner = function duplicateSpinner() {
    var $el = $('.spinner').parent(); // Get the parent element of the spinner
    var html = $('.spinner').parent().html(); // Get the HTML content of the parent element containing the spinner
    $el.append(html); // Append the HTML content to the parent element
    $('.spinner').last().addClass('spinner--right');
    $('.spinner--right').removeClass('spinner--left');
};

var paintFaces = function paintFaces() {
    $('.spinner__face').each(function (i, el) { // Loop through each spinner face element
        var $el = $(el);
        var color = $(el).attr('data-bg'); // Get the background color attribute value
        $el.children().css('backgroundImage', 'url(' + getBase64PixelByColor(color) + ')'); // Set background image using base64 pixel data
    });
};

var getBase64PixelByColor = function getBase64PixelByColor(hex) {
    if (!canvas) {
        canvas = document.createElement('canvas'); // Create a canvas element if it doesn't exist
        canvas.height = 1;
        canvas.width = 1;
    }
    if (canvas.getContext) {
        var ctx = canvas.getContext('2d'); // Get the canvas context
        ctx.fillStyle = hex; // Set the fill style to the provided color
        ctx.fillRect(0, 0, 1, 1); // Fill a pixel at position (0,0) with the provided color
        return canvas.toDataURL(); // Return the base64 encoded pixel data
    }
    return false;
};

var prepareDom = function prepareDom() {
    setIndexes(); // Set indexes for the spinner elements
    paintFaces(); // Paint the spinner faces with their respective colors
    duplicateSpinner();  // Duplicate the spinner to create a right spinner
    appendControls(); // Append controls for the carousel

};

var spin = function spin() {
    var inc = arguments.length <= 0 || arguments[0] === undefined ? 1 : arguments[0]; // Set default value for increment
    if (disabled) // Check if spinning is disabled
        return; // If disabled, exit the function
    if (!inc) // Check if increment value is zero or undefined
        return; // If zero or undefined, exit the function
    activeIndex += inc; // Increment active index by the specified value
    disabled = true; // Set spinning to disabled
    if (activeIndex >= limit) { // Check if active index exceeds the limit
        activeIndex = 0; // If so, reset active index to the beginning
    }
    if (activeIndex < 0) { // Check if active index is negative
        activeIndex = limit - 1; // If so, set active index to the last item
    }
    var $activeEls = $('.spinner__face.js-active'); // Get currently active elements
    var $nextEls = $('.spinner__face[data-index=' + activeIndex + ']'); // Get next elements based on the new active index
    $nextEls.addClass('js-next'); // Add 'js-next' class to the next elements
    if (inc > 0) { // Check if increment is positive
        $stage.addClass(SPIN_FORWARD_CLASS); // Add class for forward spinning animation
    } else { // If negative
        $stage.addClass(SPIN_BACKWARD_CLASS); // Add class for backward spinning animation
    }
    $controls.removeClass('active');
    $controls.eq(activeIndex).addClass('active');
    setTimeout(function () { // Set timeout to execute spinCallback function after a delay
        spinCallback(inc); // Call spinCallback function
    }, SPIN_DUR, inc); // Timeout duration
};

var spinCallback = function spinCallback(inc) {
    $('.js-active').removeClass('js-active'); // Remove active class from currently active item
    $('.js-next').removeClass('js-next').addClass('js-active'); // Remove next class and add active class to the next item
    $stage.addClass(DISABLE_TRANSITIONS_CLASS).removeClass(SPIN_FORWARD_CLASS).removeClass(SPIN_BACKWARD_CLASS); // Disable transitions and remove spin classes from the stage
    $('.js-active').each(function (i, el) { // Iterate over active elements
        var $el = $(el); // Convert element to jQuery object
        $el.prependTo($el.parent()); // Move the element to the beginning of its parent
    });
    setTimeout(function () { // Set timeout function
        $stage.removeClass(DISABLE_TRANSITIONS_CLASS); // Remove transitions disable class
        disabled = false; // Reset disabled flag
    }, 100); // Timeout duration
};

var attachListeners = function attachListeners() {
    // Listen for keyup event on the document
    document.onkeyup = function (e) {
        // Listen for keyup event on the document
        switch (e.keyCode) {
            // Up arrow key
        case 38:
            spin(-1); // Spin backward
            break;
             // Down arrow key
        case 40:
            spin(1); // Spin forward
            break;
        }
    };
    $controls.on('click', function (e) {
        e.preventDefault();
        if (disabled)
            return;
        var $el = $(e.target);
        var toIndex = parseInt($el.attr('data-index'), 10);
        spin(toIndex - activeIndex);
    });
};

var assignEls = function assignEls() {
     // Assign the carousel stage element to the $stage variable
    $stage = $('.carousel__stage');
};

var init = function init() {
    // Assign necessary elements
    assignEls();
    // Prepare the DOM structure
    prepareDom();
    // Attach event listeners
    attachListeners();
};

$(function () {
    // Initialize the carousel when the DOM is ready
    init();
});
