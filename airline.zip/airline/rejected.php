<?php
require_once('dbconnect.php');

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT); // Sanitize ID

    $sql = "UPDATE Bookings SET status = 'Rejected' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Redirect back to admin.php with a message
        header('Location: admin.php?message=Booking%20status%20is%20"rejected"!');
        exit();
    } else {
        // Display error message
        echo "Error updating booking status: " . $conn->error;
    }

    $stmt->close();
} else {
    // Display error message for invalid booking ID
    echo "Invalid booking ID";
}

$conn->close();
?>
