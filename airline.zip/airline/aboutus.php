<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"> <!-- Character encoding -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/> <!-- Set compatibility mode for Internet Explorer -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Configure viewport for responsive design -->
  <title>About Us</title> <!-- Set the title of the page -->
  <link rel="stylesheet" href="aboutus.css"> <!-- Link to external CSS file for about us page -->
  <link rel="stylesheet" href="style.css"> <!-- Link to external CSS file for general styles -->

   <!-- Unicons CSS -->
   <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" /> <!-- Link to Unicons CSS -->
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'> <!-- Link to Boxicons CSS -->
   <script src="main.js" defer></script> <!-- Link to main JavaScript file with deferred loading -->
</head>

<body> <!-- Start of the body section -->
  <!-- Navigation section -->
  <nav class="nav">
    <i class="uil uil-bars navOpenBtn"></i> <!-- Button for opening navigation on mobile -->
    <a href="home.php" class="logo">
      <div class="animated-word"> <!-- Animated logo -->
        <img src="logo.png" style="height: 35px;"> <!-- Logo image -->
        <div class="letter">L</div> <!-- Individual letters of the logo -->
        <div class="letter">u</div>
        <div class="letter">z</div>
        <div class="letter">a</div>
        <div class="letter">F</div>
        <div class="letter">l</div>
        <div class="letter">y</div>
      </div>
    </a>
    
    <!-- Navigation links -->
    <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->
    </ul>

    <i class="uil uil-search search-icon" id="searchIcon"></i> <!-- Search icon -->
    <div class="search-box"> <!-- Search box -->
      <i class="uil uil-search search-icon"></i>
      <input type="text" placeholder="Search here..." />
    </div>
  </nav>

  <!-- About Us section -->
  <div class="aboutus">
    <div class="aboutustitle"> <!-- Title and description of About Us section -->
      <h1>About us</h1>
      <p>Want to get to know LuzaFly better? You are invited to witness the success story of the airline flying to the 12 countries in the world.</p>
    </div>


    <!-- Container for cards -->
    <div class="containerCard">
      <!-- Card 1: Our Success Story -->
      <div class="cards">
        <div class="imgBx"> <!-- Image box -->
          <img src="https://www.nm.org//-/media/northwestern/healthbeat/images/wellness/nm-healthy-flight-travel-tnail.jpg" alt="insideplane"> <!-- Image for success story -->
        </div>
        <div class="content"> <!-- Content box -->
          <h2>Our Success Story</h2> <!-- Title of success story -->
          <p>Starting on April 5, 2003 with only two planes and fewer than 30 employees, our journey continues today as the airline flying to 14 countries in the world - celebrating our 20th year.</p> <!-- Description of success story -->
          <a href="#success-story">Witness our adventure>></a> <!-- Link to read more -->
        </div>
      </div>

      <!-- Card 2: Our Partners -->
      <div class="cards">
        <div class="imgBx"> <!-- Image box -->
          <img src="founders.jpeg" alt="teampic"> <!-- Image for partners -->
        </div>
        <div class="content"> <!-- Content box -->
          <h2>Our Partners</h2> <!-- Title of partners -->
          <p>LuzaFly has been founded by two wonderful independent women in their early 20's. Presenting our co-founders, Miss Aubdoolary Lubna & Miss Esmile Zakiyyah, working as a team to bring LuzaFly here today.</p> <!-- Description of partners -->
          <a href="home.php">Explore LuzaFly>></a> <!-- Link to explore -->
        </div>
      </div>

      <!-- Card 3: Our Mission, Vision & Values -->
      <div class="cards">
        <div class="imgBx"> <!-- Image box -->
          <img src="https://static.ffx.io/images/$zoom_0.378%2C$multiply_0.9735%2C$ratio_1.5%2C$width_756%2C$x_0%2C$y_0/t_crop_custom/q_86%2Cf_auto/c75ba2699dc612adc32a7291576d69b863018034" alt="insideplane"> <!-- Image for mission, vision & values -->
        </div>
        <div class="content"> <!-- Content box -->
          <h2>Our Mission, Vision & Values.</h2> <!-- Title of mission, vision & values -->
          <p>Working together to shape the future growth of a safe, secure and sustainable air transport industry that connects and enriches our world...</p> <!-- Description of mission, vision & values -->
          <a href="#vision-mission">Read more>></a> <!-- Link to read more -->
        </div>
      </div>

      <!-- Story section -->
      <div class="story">
        <!-- Success Story -->
        <div id="success-story"> <!-- Section for success story -->
          <img src="https://engineering.case.edu/sites/default/files/styles/715x447/public/plane-take-off-feat.jpg?itok=jMjZMlWG" class="bg"> <!-- Background image -->
          <h2>Our Success Story</h2> <!-- Title of success story -->
          <p>Starting on April 5, 2003 with only two planes and fewer than 30 employees, our journey continues today as the airline flying to 14 countries in the world - celebrating our 20th year. Our 90-year success story is marked by the strength we have gained through challenges and difficult times.</p> <!-- Detailed description of success story -->
          <img src="https://media.cnn.com/api/v1/images/stellar/prod/230207154521-02-safest-seat-on-the-plane.jpg?c=original" class="bg">
      	  <h3>An adventure in the sky that began in 2003</h3>
      	  <p>Back in 2003, the LuzaFly adventure began; an endeavor to unite people, cultures, continents, countries and cities whilst providing new, inspiring travel experiences for all. On the 5th of April 2003, we took to the skies as State Airlines Administration. Leading the way, LuzaFly's first aviator and chief executive, Fesan Evrensev, set out with a mere 30 employees and 2 aircrafts. </p>
      	  <p>In 2007, proudly flying the Mauritian national flag, we conducted our first overseas flight, from Mauritius to Istanbul. Making headway in 2010, our fleet increased to 20 aircrafts and we began to fly to new destinations: Tokyo, Nordland and Valencia.</p>
      	  <p>In 1955, taking the name of LuzaFly, we signed a document listing our extraordinary achievements. Furthermore, our name gained its ranks alongside the members of IATA, International Air Transport Association.</p>
    	  </div>

      <!-- Vision and Mission section -->
        <div class="visionmission">
          <div id="vision-mission">
            <img src="https://cdn.vectorstock.com/i/preview-1x/00/80/mission-vision-and-values-icons-symbol-trendy-vector-46710080.jpg" class="bg1">
            <h2> Mission, Vision & Values</h2>
            <h2 style="text-align: left;">Our Vision Statement</h2>
            <p>Like any other reputed brand, this airline also has a vision statement to which it wants to stick to achieve its goals. The vision statement of LuzaFly is "To be the World's Most Trusted Airlines."</p>
            <h3>Most trusted airlines</h3>
            <p>As one of the world's most trusted airlines, thousands of daily or occasional passengers depend greatly on this airline. Hence, the company tries to make everything perfect as well, which results in the hard work everyone provides that allows them to stay where they are right now with their reputation and fame. Passengers, and crew members, can trust this airline blindly because it will always follow its vision statement.</p>
            <img src="https://v2api.netflights.com/media/1863/110823nm_flightcrew-0032.jpg?anchor=center&mode=crop&width=1920&height=711&rnd=131757984208630000&quality=60" class="bg">
    
            <h2 style="text-align: left;">Our Mission Statement</h2>
            <p>When it comes to the mission statement of LuzaFly, they have done a great job. Its mission statement is "Connect the World. Reflect on the World. Respect the World. Our purpose is beyond flight." The primary purpose of this brand is to connect with different people and show them respect as their passengers. Moreover, they believe it is not just a mere service that they are providing. Instead, they are providing much more.</p>
            <h3>Connect the World</h3>
            <p>Connecting people worldwide is a critical and challenging job. People travel from one corner of the globe to another, and enabling them to do that is quite a significant responsibility.</p>
            <h3>Going Beyond Flight</h3>
            <p>LuzaFly assures the public that the only sector they focus on is not just their flight services. Instead, they are trying to provide everyone an equal footing and a safe zone where they will receive equal treatment from all. They are very fierce about their goal of making their company pursue diversity and equity.</p>
            <img src="https://www.sagetravels.com/wp-content/uploads/2022/10/flyvaluejet_305820842_1232792657265043_8518551703971679793_n.jpg" class="bg2">
    
            <h2 style="text-align: left;">Our Core Values</h2>
            <p>Similar to this highly reputed company's mission and vision statements, the core values of LuzaFly also help them to provide top-notch services to their customers. Their core values include:</p>
            <h3>Honesty</h3>
            <p>We believe that telling the truth in every situation is always the best option. Hence, they put in the effort and follow that.</p>
            <h3>Integrity</h3>
            <p>The airline crew believes that staying true to one's moral principles is always appreciated.</p>
            <h3>Respect</h3>
            <p>They work hard and always respect each client without showing partial behavior to anyone. Apart from their clients, they respect workers of varied ethnicity and racial background.</p>
            <h3>Servant Leadership</h3>
            <p>They believe in caring for everyone and providing the best services.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <footer style="bottom: -4000px;">
    <div class="footer-container">
      <div class="left box">
        <h3>Our Info</h3>
        <div class="footer-content">
          <div class="place">
            <a href="https://maps.app.goo.gl/ejazZCHjVSguPEW89"><span class="bx bxs-map"></span></a>
            <span class="text">Address: Vacoas, Plaines Wilhems, Mauritius</span>
          </div>
          <div class="phone">
            <a href="tel:+23057461432"><span class="bx bxs-phone"></span></a>
            <span class="text">Phone: +230 5746 1432</span>
          </div>

          <div class="email">
            <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank"><span class="bx bxs-envelope"></span></a>
            <span class="text">Email: luzafly@gmail.com</span>
          </div>

          <div class="social">
            <a href="https://www.facebook.com"><span class="bx bxl-facebook"></span></a>
            <a href="https://www.x.com"><span class="bx bxl-twitter"></span></a>
            <a href="https://www.instagram.com"><span class="bx bxl-instagram"></span></a>
            <a href="https://www.linkedin.com"><span class="bx bxl-linkedin"></span></a>
          </div>
        </div>
      </div>

      <div class="center box">
        <h3>Quick Links</h3>
        <div class="footer-content">
          <ul class="linkslist">
            <li><a href="home.php">Home</a></li>
            <li><a href="discover.php">Discover</a></li>
            <li><a href="booking.php">Booking</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="login.php">Log In</a></li>
          </ul>
        </div>
      </div>

      <div class="right box">
        <h3>Contact Us</h3>
        <div class="footer-content">
          <form action="contact.php" method="post">
            <div class="email">
              <div class="text">Email *</div>
              <input type="email" name ="email" required>
            </div>
            <div class="msg">
              <div class="text">Message *</div>
              <textarea rows="2" cols="25" name="message" required></textarea>
            </div>
            <button type="submit" class="bttn">Send</button>
          </form>
        </div> 
      </div>
    </div>

    <div class="bottom">
      <center>
        <span class="credit">&copy; 2023 LuzaFly. All rights reserved.</span>
      </center>
    </div>
  </footer>

  <?php
    if (isset($_GET['message'])) {
      $message = $_GET['message'];
      echo "<script>alert('$message');</script>";
    }
  ?>

  </body>
</html>

