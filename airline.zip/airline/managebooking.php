<?php
// Load the XML file
$filePath = 'booking.xml';

if (file_exists($filePath)) {
    $xml = simplexml_load_file($filePath);
} else {
    echo "<h2>No bookings found.</h2>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <meta http-equiv="X-UA-Compatible" content="ie-edge"/>

        <!--stylesheet-->
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  
        <!--Javascript for the navbar-->
        <script src="main.js" defer></script>

        <!--title of the page-->
        <br><br><br><br><title>Manage Booking</title>
    </head>

    <body>

     <!--Navbar-->
    <nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="home.php" class="logo">
            <div class="animated-word">
                <img src="logo.png" style="height: 35px;">
                <div class="letter">L</div>
                <div class="letter">u</div>
                <div class="letter">z</div>
                <div class="letter">a</div>
                <div class="letter">F</div>
                <div class="letter">l</div>
                <div class="letter">y</div>
            </div>
        </a>
            
        <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->

    </ul>

        
        <i class="uil uil-search search-icon" id="searchIcon"></i>
        <div class="search-box">
            <i class="uil uil-search search-icon"></i>
            <input type="text" placeholder="Search here..." />
        </div>
    </nav>
    <!--End of navbar-->

<div>
    <h1>Manage Bookings</h1>

    <table>
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>ID Number</th>
                <th>To Location</th>
                <th>Departure Date</th>
                <th>Return Date</th>
                <th>Class</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($xml->booking as $booking): ?>
            <tr>
                <td><?php echo htmlspecialchars($booking->{'booking-id'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'first_name'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'last_name'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'id_number'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'to_location'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'departure_date'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'return_date'}); ?></td>
                <td><?php echo htmlspecialchars($booking->{'class'}); ?></td>
                <td>
                    <div>
                        <form action="edit_booking.php" method="post" class="me-2">
                            <input type="hidden" name="booking-id" value="<?php echo htmlspecialchars($booking->{'booking-id'}); ?>">
                            <button type="submit" class="bttn">Edit</button>
                        </form>
                        <form action="delete_booking.php" method="post" onsubmit="return confirm('Are you sure you want to delete this booking?');">
                            <input type="hidden" name="booking-id" value="<?php echo htmlspecialchars($booking->{'booking-id'}); ?>">
                            <button type="submit" class="bttn">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<style>
          body {
            background-image: url("cloudbackground.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
            color: #333;
            z-index: -1;
          }
          table { 
            width: 99%;
            margin: 0 auto;
            border-collapse: separate; 
            margin-bottom: 20px; 
            border: 4px; 
            border-radius: 40px;
          }
          th, td { 
            padding: 5px; 
            border: 1px solid #ddd; 
            vertical-align: top; 
          }
          th { 
            background-color: #744B60; 
            color: white; 
            border: 1px solid #ddd;
            text-align: center;
          }
          td {
            background-color:#EBDEDD;
          }
          h1 {
            text-align: center;
          }
          tr {
            width:5px;
          }
        </style>
</body>
</html>
