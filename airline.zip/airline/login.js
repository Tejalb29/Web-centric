// Selecting DOM elements
const logregBox = document.querySelector('.logreg-box');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');

// Event listener for register link
registerLink.addEventListener('click', () => {
    logregBox.classList.add('active');
});

// Event listener for login link
loginLink.addEventListener('click', () => {
    logregBox.classList.remove('active');
});

// Function to validate login form
function validateLoginForm() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (email === "") {
        alert("Please enter an email");
        return false;
    }
    
    if (password === "") {
        alert("Please enter a password");
        return false;
    }

    // Form validation passed
    return true;
}
