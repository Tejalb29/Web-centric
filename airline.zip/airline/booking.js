$(document).ready(function() {
    $("#booking-form").submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        // Get form data
        var formData = $(this).serialize();

        // Store reference to form element
        var form = $(this);

        // AJAX request
        $.ajax({
            url: "bookingprocess.php", // URL of the server-side script
            type: "POST", // HTTP method (POST for sending data)
            data: formData,
            success: function(response) {
                console.log(response);
                // Parse the JSON response
                var jsonResponse = JSON.parse(response);
                // Handle the response
                if (jsonResponse.success) {
                    // Update form content with success message and booking details
                    form.html("<p style='text-align: center; font-weight: 1000'>Booking successful!</p>" +
                        "<p>Name: " + jsonResponse.first_name + " " + jsonResponse.last_name + "</p>" +
                        "<p>Destination: " + jsonResponse.travelling_to + "</p>" +
                        "<p>Number of days staying: " + jsonResponse.num_days_staying + "</p>" +
                        "<p>Total Price: $" + jsonResponse.total_price + "</p>" +
                        "<button onclick='window.history.back();'>Explore more!</button>");
                } else {
                    // Update form content with error message and "Go Back" button
                    form.html("<p>" + jsonResponse.message + "</p>" +
                        "<button type='button' onclick='window.location.href=\"booking.php\"'>Go Back</button>");
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                // Handle AJAX request errors
                console.error("AJAX error:", textStatus, errorThrown);
                form.html("<p>An error occurred during booking. Please try again.</p>" +
                    "<button type='button' onclick='window.location.href=\"booking.php\"'>Go Back</button>");
            }
        });
    });
});
