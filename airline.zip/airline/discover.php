
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tags -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Discover</title>

  <!-- Custom stylesheets -->
  <link rel="stylesheet" href="discover.css">
  <link rel="stylesheet" href="style.css">

   <!-- Unicons CSS -->
   <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   
   <!-- JavaScript files -->
   <script src="main.js" defer></script>
   
   <!-- Normalize CSS -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css" rel="stylesheet" type="text/css">
   
   <!-- Boxicons CSS -->
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   
   <!-- jQuery for pop-up form -->
   <script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
   
   <!-- Discover-specific JavaScript -->
   <script src="discover.js" defer></script>
</head>

<body> 
  <!-- Navigation bar -->
  <nav class="nav">
    <!-- Navigation open button -->
    <i class="uil uil-bars navOpenBtn"></i>
    
    <!-- Logo with animated letters -->
    <a href="home.php" class="logo">
      <div class="animated-word">
        <img src="logo.png" style="height: 35px;">
        <div class="letter">L</div>
        <div class="letter">u</div>
        <div class="letter">z</div>
        <div class="letter">a</div>
        <div class="letter">F</div>
        <div class="letter">l</div>
        <div class="letter">y</div>
      </div>
    </a>
    
    <!-- Navigation links -->
    <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->
    </ul>

    <!-- Search icon and search box -->
    <i class="uil uil-search search-icon" id="searchIcon"></i>
    <div class="search-box">
      <i class="uil uil-search search-icon"></i>
      <input type="text" placeholder="Search here..." />
    </div>
  </nav>
    <!--page title-->
  <div class="title">
    <h1>Explore the World with LuzaFly</h1>
    <p>Experience unforgettable journeys to breathtaking destinations</p>
  </div>

  <!--Carousel using Jquery and CSS3-->
  <div class="carousel">
    <div class="carousel__control"></div>
    <div class="carousel__stage">
      <div class="spinner spinner--left">
        <div class="spinner__face js-active" data-bg="#27323b">
          <div class="content" data-type="carousel-1">
           
          <!--Turkey-->
          <div class="content__left">
              <h1>TURKEY<br>
                <span>Istanbul</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Where ancient history and vibrant culture converge against a backdrop of stunning landscapes. From the bustling markets of Istanbul to the tranquil beaches of the Mediterranean coast, Turkey offers a captivating blend of old-world charm and modern allure. Immerse yourself in the rich tapestry of Turkish traditions where every corner tells a story.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>

              <h3 class="content__index">01</h3>
            </div>
          </div>
        </div>

        <!--Japan-->
        <div class="spinner__face" data-bg="#19304a">
          <div class="content" data-type="carousel-2">
            <div class="content__left">
              <h1>JAPAN<br>
                <span>Tokyo</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>A dynamic fusion of tradition and innovation in Japan's bustling capital. Explore vibrant neighborhoods, savor exquisite cuisine, and witness the seamless blend of ancient temples with modern skyscrapers. From the serene gardens of Shinjuku Gyoen to the electric energy of Shibuya Crossing, Tokyo offers a captivating experience for every traveler. Discover the unique charm of this metropolis where ancient traditions meet cutting-edge technology.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>

              <h3 class="content__index">02</h3>
            </div>
          </div>
        </div>

        <!--Spain-->
        <div class="spinner__face" data-bg="#433431">
          <div class="content" data-type="carousel-3">
            <div class="content__left">
              <h1>SPAIN<br>
                <span>Valencia</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Experience the enchanting blend of history, culture, and modernity in the coastal gem of Valencia. Wander through charming old town streets, marvel at futuristic architecture like the City of Arts and Sciences, and savor delicious paella by the Mediterranean Sea. Valencia beckons with its warm climate, rich heritage, and a tapestry of experiences waiting to be explored.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">03</h3>
            </div>
          </div>
        </div>

        <!--Norway-->
        <div class="spinner__face" data-bg="#7f7f7f">
          <div class="content" data-type="carousel-4">
            <div class="content__left">
              <h1>NORWAY<br>
                <span>Nordland</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Embark on a journey to the rugged landscapes and pristine beauty of Nordland. Explore dramatic fjords, majestic mountains, and picturesque coastal villages that dot the Arctic Circle. Immerse yourself in the rich culture of the Sami people, witness the mesmerizing Northern Lights dance across the sky, and breathe in the fresh Arctic air. From hiking in the Lofoten Islands to cruising along the stunning coastline, Nordland offers a wilderness escape like no other.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">04</h3>
            </div>
          </div>
        </div>

        <!--Morroco-->
        <div class="spinner__face" data-bg="#4169e1">
          <div class="content" data-type="carousel-5">
            <div class="content__left">
              <h1>MORROCO<br>
                <span>Marrakech</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Step into a world of vibrant colors, exotic scents, and ancient wonders in the bustling city of Marrakech. Lose yourself in the maze-like streets of the medina, where bustling souks offer a treasure trove of spices, textiles, and handicrafts. Marvel at the architectural splendor of the historic palaces and mosques, such as the iconic Koutoubia Mosque and the Bahia Palace. Indulge in the tantalizing flavors of Moroccan cuisine, from aromatic tagines to sweet mint tea. Experience the magic of Marrakech's lively Djemaa el-Fna square, where snake charmers, storytellers, and musicians create an unforgettable spectacle.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">05</h3>
            </div>
          </div>
        </div>

        <!--Philipines-->
        <div class="spinner__face" data-bg="#847c6d">
          <div class="content" data-type="carousel-6">
            <div class="content__left">
              <h1>PHILLIPINES<br>
                <span>Palawan Island</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Embark on a tropical paradise adventure to Palawan Island, where pristine beaches, crystal-clear waters, and lush jungles await. Explore the enchanting underground river in Puerto Princesa, lounge on the powdery sands of El Nido, and snorkel in the vibrant coral reefs of Coron. Immerse yourself in the rich biodiversity of the island, home to exotic wildlife and stunning marine life. Experience the warm hospitality of the locals, savor delectable Filipino cuisine, and witness breathtaking sunsets over the horizon. Palawan Island beckons with its natural beauty, serene landscapes, and a tranquil escape from the hustle and bustle of everyday life.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">06</h3>
            </div>
          </div>
        </div>

        <!--Dubai-->
        <div class="spinner__face" data-bg="#746c70">
          <div class="content" data-type="carousel-7">
            <div class="content__left">
              <h1>UAE<br>
                <span>Dubai</span></h1>
            </div>


            <div class="content__right">
              <div class="content__main">
                <p>Dubai, a city of contrasts and opulence, offers a unique blend of modernity and tradition. Explore towering skyscrapers like the iconic Burj Khalifa, the world's tallest building, and marvel at the stunning Dubai Fountain show. Indulge in luxury shopping at the Dubai Mall or traditional souks for a cultural shopping experience. Immerse yourself in the rich Emirati culture at the Dubai Museum and Jumeirah Mosque. Enjoy pristine beaches, desert safaris, and thrilling theme parks like Atlantis, The Palm. Dubai is a melting pot of experiences, where the old meets the new in a dynamic and cosmopolitan setting.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">07</h3>
            </div>
          </div>
        </div>

        <!--Greece-->
        <div class="spinner__face" data-bg="#1f3039">
          <div class="content" data-type="carousel-8">
            <div class="content__left">
              <h1>GREECE<br>
                <span>Santorini</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Santorini, Greece, a picturesque paradise in the Aegean Sea, is renowned for its stunning whitewashed buildings perched on cliffs overlooking the deep blue waters. Explore the charming villages of Oia and Fira with their iconic blue-domed churches and breathtaking sunsets. Relax on the black sand beaches of Perissa and Kamari or take a boat tour to the volcanic islands. Discover the rich history at the ancient ruins of Akrotiri and enjoy delicious Greek cuisine at seaside tavernas. Santorini is a romantic destination offering unparalleled beauty, warm hospitality, and unforgettable experiences.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">08</h3>
            </div>
          </div>
        </div>

        <!--Korea-->
        <div class="spinner__face" data-bg="#312f2d">
          <div class="content" data-type="carousel-9">
            <div class="content__left">
              <h1>KOREA<br>
                <span>Soeul</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Seoul, the capital of South Korea, is a vibrant metropolis where modern skyscrapers, high-tech subways, and pop culture meet Buddhist temples, palaces, street markets, and traditional Korean houses (hanok). The city offers a unique blend of ancient history and cutting-edge technology, making it a fascinating destination for travelers. Explore the bustling shopping districts, enjoy delicious Korean cuisine, visit historic landmarks like Gyeongbokgung Palace and Bukchon Hanok Village, and experience the lively nightlife in areas like Hongdae and Itaewon. Seoul truly has something for everyone, from history buffs to foodies to K-pop fans.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">09</h3>
            </div>
          </div>
        </div>

        <!--Uzbekistan-->
        <div class="spinner__face" data-bg="#90674c">
          <div class="content" data-type="carousel-10">
            <div class="content__left">
              <h1>UZBEKISTAN<br>
                <span>Samarkand</span></h1>
            </div>

            <!--Paragraph-->
            <div class="content__right">
              <div class="content__main">
                <p>Samarkand, located in Uzbekistan, is a city steeped in history and culture, known for its stunning Islamic architecture and ancient Silk Road heritage. This UNESCO World Heritage Site boasts magnificent landmarks such as the Registan Square, Shah-i-Zinda necropolis, and the Bibi-Khanym Mosque, showcasing the city's rich architectural legacy. Visitors can immerse themselves in the city's vibrant bazaars, where traditional crafts and spices are sold, or explore the tranquil beauty of the Gur-e-Amir Mausoleum, the final resting place of the great conqueror Tamerlane. Samarkand is a captivating destination that offers a glimpse into Uzbekistan's storied past and architectural wonders.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">10</h3>
            </div>
          </div>
        </div>

        <!--France-->
        <div class="spinner__face" data-bg="#7b7484">
          <div class="content" data-type="carousel-11">
            <div class="content__left">
              <h1>FRANCE<br>
                <span>Paris</span></h1>
            </div>


            <div class="content__right">
              <div class="content__main">
                <p>Paris, the capital of France, is a city synonymous with romance, art, and culture. Known as the "City of Light," Paris is home to iconic landmarks such as the Eiffel Tower, Louvre Museum, and Notre-Dame Cathedral. Stroll along the charming streets lined with cafes and boutiques, explore world-class art galleries and fashion houses, and savor exquisite French cuisine in cozy bistros. From the bohemian vibe of Montmartre to the grandeur of the Champs-Élysées, Paris offers a perfect blend of history, architecture, and sophistication that enchants visitors from around the globe. Experience the magic of Paris, where every corner tells a story and every moment is filled with beauty.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">11</h3>
            </div>
          </div>
        </div>

        <!--Japan-->
        <div class="spinner__face" data-bg="#095859">
          <div class="content" data-type="carousel-12">
            <div class="content__left">
              <h1>JAPAN<br>
                <span>Yamaguchi</span></h1>
            </div>


            <div class="content__right">
              <div class="content__main">
                <p>Yamaguchi, a prefecture in Japan, is a region rich in history, nature, and cultural heritage. Located in the western part of Honshu island, Yamaguchi offers a mix of traditional charm and modern amenities. Visitors can explore historic sites like the Akiyoshido Cave, Ruriko-ji Temple, and the iconic Kintai Bridge, which are testaments to the region's past as a feudal stronghold. Nature lovers can enjoy scenic landscapes in places like Akiyoshidai Plateau and Tsunoshima Island with its picturesque beaches. Yamaguchi is also known for its delicious cuisine, including local specialties like fugu (blowfish) and freshly caught seafood. Immerse yourself in the beauty and culture of Yamaguchi for a truly enriching travel experience in Japan.</p>
                <button class="redirect-btn btn" onclick="document.location='booking.php'">Book now!</button>
              </div>
              <h3 class="content__index">12</h3>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!--Footer-->
  <footer style="bottom: -470px;" >
  <div class="footer-container">

  <!--Left side-->
    <div class="left box">
      <h3>Our Info</h3>
      <div class="footer-content">
        <div class="place">
      <a href="https://maps.app.goo.gl/ejazZCHjVSguPEW89"><span class="bx bxs-map"></span></a>
      <span class="text">Address: Vacoas, Plaines Wilhems, Mauritius</span>
    </div>

    <div class="phone">
      <a href="tel:+23057461432"><span class="bx bxs-phone"></span></a>
        <span class="text">Phone: +230 5746 1432</span>
    </div>

    <div class="email">
      <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank"><span class="bx bxs-envelope"></span></a>
        <span class="text">Email: luzafly@gmail.com</span>
    </div>

    <!--Social media with icons-->
    <div class="social">
      <a href="https://www.facebook.com"><span class="bx bxl-facebook"></span></a>
      <a href="https://www.x.com"><span class="bx bxl-twitter"></span></a>
      <a href="https://www.instagram.com"><span class="bx bxl-instagram"></span></a>
      <a href="https://www.linkedin.com"><span class="bx bxl-linkedin"></span></a>
    </div>

    </div>
  </div>

  <!--Center part-->
    <div class="center box">
      <!--Quick links to other pages-->
      <h3>Quick Links</h3>
      <div class="footer-content">
      <ul class="linkslist">
        <li><a href="home.php">Home</a></li>
        <li><a href="discover.php">Discover</a></li>
        <li><a href="booking.php">Booking</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="login.php">Log In</a></li>
      </ul>
    </div>
  </div>

  <!--Contat us form-->
   <div class="right box">
      <h3>Contact Us</h3>
      <div class="footer-content">
        <form action="contact.php" method="post">
          <div class="email">
            <div class="text">Email *</div>
            <input type="email" name ="email" required>
          </div>

          <div class="msg">
            <div class="text">Message *</div>
            <textarea rows="2" cols="25" name="message" required></textarea>
          </div>

          <!--Submit button-->
          <button type="submit" class="bttn">Send</button>
          </div>
        </form>

      </div>
    </div>
  </div>

  <!--Copyright-->
  <div class="bottom">
    <center>
      <span class="credit">&copy; 2023 LuzaFly. All rights reserved.</span>
    </center>
  </div>
  </footer>

   <!--Check if the message variable is set using php-->
   <?php
   if (isset($_GET['message'])) {
    $message = $_GET['message'];
    echo "<script>alert('$message');</script>";
  }
  ?>

</body>
</html>