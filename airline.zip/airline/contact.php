<?php
include("dbconnect.php"); // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") { // Check if the request method is POST
    // Validate and sanitize user inputs
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL); // Validate email
    $message = htmlspecialchars($_POST['message']); // Sanitize message

    if ($email && $message) { // Check if both email and message are valid
        $query = "INSERT INTO contact(email, message) VALUES(?, ?)"; // SQL query to insert data into the contact table
        $statement = mysqli_prepare($conn, $query); // Prepare SQL statement
        mysqli_stmt_bind_param($statement, 'ss', $email, $message); // Bind parameters

        if (mysqli_stmt_execute($statement)) { // Execute SQL statement
            // Redirect back to home.php with a success message
            header('Location: home.php?message=Message%20sent%20successfully✨');
            exit(); // Stop further execution
        } else {
            // Redirect back to home.php with a failure message if message sending fails
            header('Location: home.php?message=Message%20sending%20failed😔');
        }
        mysqli_stmt_close($statement); // Close statement
    } else {
        // Redirect back to home.php with an error message if email or message is invalid
        header('Location: home.php?message=Invalid%20email%20or%20message😔');
    }
}
?>
