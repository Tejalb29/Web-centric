
// Select the first element with the class "nav" and assign it to the variable `nav`
const nav = document.querySelector(".nav"),
// Select the first element with the ID "searchIcon" and assign it to the variable `searchIcon`
  searchIcon = document.querySelector("#searchIcon"),
  // Select the first element with the class "navOpenBtn" and assign it to the variable `navOpenBtn`
  navOpenBtn = document.querySelector(".navOpenBtn"),
  // Select the first element with the class "navCloseBtn" and assign it to the variable `navCloseBtn`
  navCloseBtn = document.querySelector(".navCloseBtn");

  // Add an event listener to the searchIcon element that listens for click events
searchIcon.addEventListener("click", () => {
  // Toggle the "openSearch" class on the nav element
  nav.classList.toggle("openSearch");
  // Remove the "openNav" class from the nav element
  nav.classList.remove("openNav");
  // If the nav element has the "openSearch" class
  if (nav.classList.contains("openSearch")) {
    // Replace the "uil-search" class with the "uil-times" class on the searchIcon element
    return searchIcon.classList.replace("uil-search", "uil-times");
  }
  // Otherwise, replace the "uil-times" class with the "uil-search" class on the searchIcon element
  searchIcon.classList.replace("uil-times", "uil-search");
});

// Add an event listener to the navOpenBtn element that listens for click events
navOpenBtn.addEventListener("click", () => {
  // Add the "openNav" class to the nav element
  nav.classList.add("openNav");
  // Remove the "openSearch" class from the nav element
  nav.classList.remove("openSearch");
  // Replace the "uil-times" class with the "uil-search" class on the searchIcon element
  searchIcon.classList.replace("uil-times", "uil-search");
});

// Add an event listener to the navCloseBtn element that listens for click events
navCloseBtn.addEventListener("click", () => {
  // Remove the "openNav" class from the nav element
  nav.classList.remove("openNav");
});