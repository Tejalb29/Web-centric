<?php
$filePath = 'booking.xml';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking-id'])) {
    $bookingIdToUpdate = $_POST['booking-id'];

    // Load the XML file
    if (file_exists($filePath)) {
        $xml = simplexml_load_file($filePath);

        // Find the booking to update
        foreach ($xml->booking as $booking) {
            if ($booking->{'booking-id'} == $bookingIdToUpdate) {
                // Update the booking details from the form data
                $booking->{'first_name'} = $_POST['first-name'];
                $booking->{'last_name'} = $_POST['last-name'];
                $booking->{'id_number'} = $_POST['id-number'];
                $booking->{'to_location'} = $_POST['to-location'];
                $booking->{'departure_date'} = $_POST['departure-date'];
                $booking->{'return_date'} = $_POST['return-date'];
                $booking->{'class'} = $_POST['class'];

                // Save the updated XML file
                $xml->asXML($filePath);

                // Redirect to view data page to see the updated data
                header("Location: managebooking.php");
                exit;
            }
        }
        // If the booking ID was not found
        header("Location: managebooking.php?message=Booking%20ID%20not%20found");
        exit;
    } else {
        // If the XML file doesn't exist
        header("Location: managebooking.php?message=Error%20loading%20XML%20file");
        exit;
    }
} else {
    echo "Invalid request!";
    exit;
}
