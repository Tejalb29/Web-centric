<?php
$filePath = 'booking.xml';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking-id'])) {
    $bookingIdToDelete = $_POST['booking-id'];

    // Load the XML file
    if (file_exists($filePath)) {
        $xml = simplexml_load_file($filePath);

        // Loop through all bookings to find the one to delete
        $index = 0;
        foreach ($xml->booking as $booking) {
            if ($booking->{'booking-id'} == $bookingIdToDelete) {
                // Remove the booking
                unset($xml->booking[$index]);
                
                // Save the updated XML back to the file
                $xml->asXML($filePath);

                // Redirect with success message
                header("Location: managebooking.php?message=Booking%20deleted%20successfully");
                exit;
            }
            $index++;
        }
        // If the booking ID was not found, redirect with error message
        header("Location: managebooking.php?message=Booking%20ID%20not%20found");
        exit;
    }
}
