
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Booking</title>
  <link  rel="stylesheet" href="booking.css"> 
  
  <!-- css for navbar -->
  <link rel="stylesheet" href="style.css">

   <!-- Unicons CSS -->
   <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <script src="main.js" defer></script>

   <!--Import Jquery library-->
   
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <!--booking js-->
   <script src="booking.js" defer></script>
</head>

<body> 
  <!--Navbar-->
  <nav class="nav">
    <i class="uil uil-bars navOpenBtn"></i>
    <a href="home.php" class="logo">
      <div class="animated-word">
      <img src="logo.png" style="height: 35px;">
        <div class="letter">L</div>
        <div class="letter">u</div>
        <div class="letter">z</div>
        <div class="letter">a</div>
        <div class="letter">F</div>
        <div class="letter">l</div>
        <div class="letter">y</div>
      </div>
    </a>
    
    <!--Quick links-->
    <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->
    </ul>

    <!--Search icon-->
    <i class="uil uil-search search-icon" id="searchIcon"></i>
    <div class="search-box">
      <i class="uil uil-search search-icon"></i>
      <input type="text" placeholder="Search here..." />
    </div>
    </nav>
    <!--End of Navbar-->

    <!--Start of booking-->
    <!---Container for form-->
    <div class="image">
    <div class="container">
    <div class="content">
    <div class="booking-form">
      <div class="form-container">

      <!--Start of form-->
        <form id="booking-form" action="bookingprocess.php" method="post">
          
        <!--form header-->
        <h1 style="text-align: center;">LuzaFly Booking Form</h1>
        <div class="name-input">
          
        <!--First name-->
        <div>
            <label for="first-name">First Name:</label>
            <input type="text" id="first-name" name="first-name">
          </div>
         
          <!--Last name-->
          <div>
            <label for="last-name">Last Name:</label>
            <input type="text" id="last-name" name="last-name">
          </div>
        </div>
        <!--ID Number-->
        <label for="id-number">ID Number:</label>
        <input type="text" id="id-number" name="id-number">
      
        <!--Travelling to-->
        <label for="to-location">Travelling to:</label>
        <select id="to-location" name="to-location">

          <!--Dropdown for list of destinations-->
          <option value="Istanbul, Turkey">Istanbul, Turkey</option>
          <option value="Tokyo, Japan">Tokyo, Japan</option>
          <option value="Valencia, Spain">Valencia, Spain</option>
          <option value="Nordland, Norway">Nordland, Norway</option>
          <option value="Marrakech, Morocco">Marrakech, Morocco</option>
          <option value="Palawan Island, Philippines">Palawan Island, Philippines</option>
          <option value="Dubai, United Arab Emirates">Dubai, United Arab Emirates</option>
          <option value="Santorini, Greece">Santorini, Greece</option>
          <option value="Seoul, Korea">Seoul, Korea</option>
          <option value="Samarkand, Uzbekistan">Samarkand, Uzbekistan</option>
          <option value="Paris, France">Paris, France</option>
          <option value="Yamaguchi, Japan">Yamaguchi, Japan</option>
        </select>
        <!--End of drodpwn for destinations-->

        <!--Departure date-->
        <label for="departure-date">Departure Date:</label>
        <input type="date" id="departure-date" name="departure-date">
      
        <!--Return date-->
        <label for="return-date">Return Date:</label>
        <input type="date" id="return-date" name="return-date">
      
        <!--Airline class-->
        <label for="class">Airline class:</label>
        <select id="class" name="class" >
          <!--Dropdown for airline classes-->
          <option value="economy">Economy class</option>
          <option value="business">Business class</option>
          <option value="first-class">First Class</option>
        </select>
        <!--End of dropdown-->

        <!--card details-->
        <div class="card-details">
          <div>
            <!--Card type-->
            <label for="card-type">Card Type:</label>
            <select id="card-type" name="card-type" >
              <!--dropdown for card types-->
              <option value="visa">Visa</option>
              <option value="mastercard">Mastercard</option>
            </select>
            <!--End of dropdown-->
          </div>

          <!--Card number-->
          <div>
            <label for="card-number">Card Num:</label>
            <input type="text" id="card-number" name="card-number" minlength="19" maxlength="19">
          </div>

          <!--CSV-->
          <div>
            <label for="csv">CSV:</label>
            <input type="text" id="csv" name="csv" minlenght="3" maxlength="3">
          </div>

          <!--Expiry date-->
          <div>
            <label for="expiry-month">Expiry Month:</label>
            <select id="expiry-month" name="expiry-month" >
              <!--Dropdown for expiry month-->
              <option value="01"> January</option>
              <option value="02">February</option>
              <option value="03">March</option>
              <option value="04">April</option>
              <option value="05">May</option>
              <option value="06">June</option>
              <option value="07">July</option>
              <option value="08">August</option>
              <option value="09">September</option>
              <option value="10">October</option>
              <option value="11">November</option>
              <option value="12">December</option>
            </select>
            <!--End of dropdown-->
          </div>

          <!--Expiry year-->
          <div>
            <label for="expiry-year">Expiry Year:</label>
            <select id="expiry-year" name="expiry-year" >
              <!--dropdown for expiry year-->
              <option value="2023">2023</option>
              <option value="2024">2024</option>
              <option value="2025">2025</option>
              <option value="2026">2026</option>
              <option value="2027">2027</option>
              <option value="2028">2028</option>
            </select>
            <!--End of dropdown-->
          </div>
        </div>

        <!--Submit button-->
        <button type="submit">Book Now</button>
        </form>
        </div>
      </div>
    </div>
    </div>
    </div>

    <!--Start of footer-->
    <footer style="bottom: -820px;">
    <div class="footer-container">
      <!--Left side of the footer-->
    <div class="left box">
      <h3>Our Info</h3>
      <div class="footer-content">
        <div class="place">
          <!--Location-->
      <a href="https://maps.app.goo.gl/ejazZCHjVSguPEW89"><span class="bx bxs-map"></span></a>
      <span class="text">Address: Vacoas, Plaines Wilhems, Mauritius</span>
    </div>
    <!--Phone-->
    <div class="phone">
      <a href="tel:+23057461432"><span class="bx bxs-phone"></span></a>
        <span class="text">Phone: +230 5746 1432</span>
    </div>

    <!--Email-->
    <div class="email">
      <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank"><span class="bx bxs-envelope"></span></a>
        <span class="text">Email: luzafly@gmail.com</span>
    </div>

    <!--Social media with icons-->
    <div class="social">
      <a href="https://www.facebook.com"><span class="bx bxl-facebook"></span></a>
      <a href="https://www.x.com"><span class="bx bxl-twitter"></span></a>
      <a href="https://www.instagram.com"><span class="bx bxl-instagram"></span></a>
      <a href="https://www.linkedin.com"><span class="bx bxl-linkedin"></span></a>
    </div>
    </div>
  </div>

  <!--Center part of footer-->
    <div class="center box">
      <!--Quick links to other pages-->
      <h3>Quick Links</h3>
      <div class="footer-content">
      <ul class="linkslist">
        <li><a href="home.php">Home</a></li>
        <li><a href="discover.php">Discover</a></li>
        <li><a href="booking.php">Booking</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="login.php">Log In</a></li>
      </ul>
    </div>
  </div>

  <!--Contact form-->
   <div class="right box">
      <h3>Contact Us</h3>
      <div class="footer-content">
        <form action="contact.php" method="post">
          <div class="email">
            <div class="text">Email *</div>
            <input type="email" name ="email" required>
          </div>

          <div class="msg">
            <div class="text">Message *</div>
            <textarea rows="2" cols="25" name="message" required></textarea>
          </div>
          <
          <button type="submit" class="bttn">Send</button>

          </div>
        </form>
      </div>
    </div>
  </div>

  <!--Copyright-->
  <div class="bottom">
    <center>
    <span class="credit">&copy; 2023 LuzaFly. All rights reserved.</span>
    </center>
    </div>
    </footer>
    <!--End of footer-->

    <!--Check if the message variable is set using php-->
    <?php
if (isset($_GET['message'])) {
  // Get the message value
    $message = $_GET['message'];
    // Display the message in an alert box
    echo "<script>alert('$message');</script>";
}
?>

</body>
</html>