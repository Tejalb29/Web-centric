<?php
require_once('dbconnect.php'); // Include database connection

if (isset($_GET['id'])) { // Check if booking ID is set in the URL
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT); // Sanitize the ID

    // Prepare and execute SQL statement to update booking status to "Approved"
    $sql = "UPDATE Bookings SET status = 'Approved' WHERE id = ?";
    $stmt = $conn->prepare($sql); // Prepare SQL statement
    $stmt->bind_param("i", $id); // Bind parameters
    if ($stmt->execute()) { // Execute SQL statement
        // Redirect back to admin.php with a success message
        header('Location: admin.php?message=Booking%20status%20is%20"approved"!');
        exit(); // Stop further execution
    } else {
        // Display error message if updating status fails
        echo "Error updating booking status: " . $conn->error;
    }

    $stmt->close(); // Close statement
} else {
    // Display error message for invalid booking ID
    echo "Invalid booking ID";
}

$conn->close(); // Close database connection
?>
