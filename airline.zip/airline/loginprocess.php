<html>
<link rel="stylesheet" href="login.css">
<link rel="stylesheet" href="style.css">
</html>

<?php
include("dbconnect.php");

if(isset($_POST['submit'])) {
    // Check if email and password are empty
    if(empty($_POST['email']) || empty($_POST['password'])) {
        echo "<div class='wrapper'>
            <div class='message'>
                <h3>Please fill in all required fields.</h3>
                <br>
                <a href='login.php'><button class='btn'>Go Back</button></a>
            </div>
        </div>";
        exit; // Stop further execution
    }

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email and password match a user in the database
    $query = mysqli_prepare($conn, "SELECT * FROM Users WHERE Email = ?");
    mysqli_stmt_bind_param($query, "s", $email);
    mysqli_stmt_execute($query);
    $result = mysqli_stmt_get_result($query);

    if(mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        // Verify password
        if(password_verify($password, $user['Password'])) {
            // Password is correct, start a session and redirect based on user type
            session_start();
            $_SESSION['user'] = $user;
            if ($email === 'admin@gmail.com') {
                header("Location: admin.php");
            } else {
                header("Location: home.php");
            }
            exit; // Stop further execution
        } else {
            // Password is incorrect, redirect back to login page with an error message
            echo "<div class='wrapper'>
                <div class='message'>
                    <h3>Wrong Password. Please try again.</h3>
                    <br>
                    <a href='login.php'><button class='btn'>Go Back</button></a>
                </div>
            </div>";
            exit; // Stop further execution
        }
    } else {
        // Email is not registered, redirect back to login page with an error message
        echo "<div class='wrapper'>
            <div class='message'>
                <h3>Your email is not registered.<br> Please try again or register.</h3>
                <br>
                <a href='login.php'><button class='btn'>Go Back</button></a>
            </div>
        </div>";
        exit; // Stop further execution
    }
}
?>
