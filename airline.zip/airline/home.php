<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <meta http-equiv="X-UA-Compatible" content="ie-edge"/>

        <!--fonts and icons-->
        <script src="https://kit.fontawesome.com/ccbd4d6bc1.js" crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
        <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;900&display=swap" rel="stylesheet"/>

        <!--stylesheet-->
        <link rel="stylesheet" href="home.css"/>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  
        <!--Javascript for the navbar-->
        <script src="main.js" defer></script>

        <!--title of the page-->
        <title>LuzaFly - Home</title>
    </head>

    <body>

     <!--Navbar-->
    <nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="home.php" class="logo">
            <div class="animated-word">
                <img src="logo.png" style="height: 35px;">
                <div class="letter">L</div>
                <div class="letter">u</div>
                <div class="letter">z</div>
                <div class="letter">a</div>
                <div class="letter">F</div>
                <div class="letter">l</div>
                <div class="letter">y</div>
            </div>
        </a>
            
        <ul class="nav-links">
      <i class="uil uil-times navCloseBtn"></i> <!-- Button for closing navigation on mobile -->
      <li><a href="home.php">Home</a></li> <!-- Home link -->
      <li><a href="discover.php">Discover</a></li> <!-- Discover link -->
      <li><a href="booking.php">Booking</a></li> <!-- Booking link -->
      <li><a href="viewdata.html">View Data</a></li>
      <li><a href="managebooking.php">Manage Booking</a></li>
      <li><a href="aboutus.php">About Us</a></li> <!-- About Us link -->
      <li><a href="login.php">Log In</a></li> <!-- Log In link -->

    </ul>

        
        <i class="uil uil-search search-icon" id="searchIcon"></i>
        <div class="search-box">
            <i class="uil uil-search search-icon"></i>
            <input type="text" placeholder="Search here..." />
        </div>
    </nav>
    <!--End of navbar-->

    <header>
        <!--container element with the glass effect-->
        <div class="glass">

            <!--heading element on the glass effect-->
            <h1 class="h-glass">Luza</h1>
            <div>
                <div>
                    <!--icon using the Font Awesome library (https://fontawesome.com/). It indicates a solid route icon with a size of 2x.-->
                    <i class="fas fa-route fa-2x"></i>
                </div>

                <div>
                    <!--Subheading-->
                    <h2>Explore travel destinations with LuzaFly</h2>
                    <p>Embark on a journey beyond imagination with LuzaFly!</p>

                    <!--hyperlink leading to the discover page-->
                    <a href="discover.php">
                        Discover more!
                        <!--Creates another Font awesome icon, displaying a right arrow to indicate the direction of the link-->
                        <i class="fas fa-long-arrow-atl-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!--Heading on the other side of the glass effect-->
        <h1 class="h-regular">Fly</h1>
    </header>

       <!--Paragraph below the glass effect-->
    <section>
        <p>"Welcome to LuzaFly – where adventure knows no bounds. From sun-kissed beaches to towering peaks, we're here to make your travel dreams a reality.<br><br>

            At LuzaFly, we redefine travel, creating experiences as unique as you are. Our dedicated team crafts personalized experiences that linger in your memory long after you return home.<br><br>

            Embark on an extraordinary adventure with LuzaFly – let us be your guide to unforgettable moments and boundless exploration. Your journey starts here!"</p>
    </section>
        
       <!--inline style positions the footer element 510 pixels from the bottom of the viewport-->
    <footer style="bottom: -510px;">
    
    <!--Contains all the footer information-->
    <div class="footer-container">
        
        <!--Contains info section in the footer-->
        <div class="left box">
            <h3>Our Info</h3>
            <div class="footer-content">
                <div class="place">
                    <!--Opens Google Map to our location-->
                    <a href="https://maps.app.goo.gl/ejazZCHjVSguPEW89"><span class="bx bxs-map"></span></a>
                    <span class="text">Address: Vacoas, Plaines Wilhems, Mauritius</span>
                </div>
                <!--Opens phone application on your device to call the comapny-->
                <div class="phone">
                    <a href="tel:+23057461432"><span class="bx bxs-phone"></span></a>
                    <span class="text">Phone: +230 5746 1432</span>
                </div>
                <!--Opens Gmail to send an email to the company-->
                <div class="email">
                    <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank"><span class="bx bxs-envelope"></span></a>
                    <span class="text">Email: luzafly@gmail.com</span>
                </div>

                <!--Links to our various social media accounts with the social media icons respectively-->
                <div class="social">
                    <a href="https://www.facebook.com"><span class="bx bxl-facebook"></span></a>
                    <a href="https://www.x.com"><span class="bx bxl-twitter"></span></a>
                    <a href="https://www.instagram.com"><span class="bx bxl-instagram"></span></a>
                    <a href="https://www.linkedin.com"><span class="bx bxl-linkedin"></span></a>
                </div>
            </div>
        </div>
<!--Middle section of the footer containing the links to all the pages-->
<div class="center box">
    <h3>Quick Links</h3>
    <div class="footer-content">
        <ul class="linkslist">
            <li><a href="home.php">Home</a></li>
            <li><a href="discover.php">Discover</a></li>
            <li><a href="booking.php">Booking</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="login.php">Log In</a></li>
        </ul>
    </div>
</div>

<!--Right side of the footer-->
<div class="right box">
    <h3>Contact Us</h3>
    <div class="footer-content">
        <form action="contact.php" method="post">
            <!--Contains a form where user can input their email-->
            <div class="email">
                <div class="text">Email *</div>
                <input type="email" name ="email" required>
            </div>

            <!--Users enter their respective message to the company or any query-->
            <div class="msg">
                <div class="text">Message *</div>
                <!--Inline CSS for the contact us form-->
                <textarea rows="2" cols="25" name="message" required></textarea>
            </div>
            <!--Submit button for the contact us form-->
            <button type="submit" class="bttn">Send</button>
        </form>
    </div>
</div>
</div>

<!--Copyright information at the end of the page-->
<div class="bottom">
    <center>
        <span class="credit">&copy; 2023 LuzaFly. All rights reserved.</span>
    </center>
</div>
</footer>
<?php
if (isset($_GET['message'])) {
    $message = $_GET['message'];
    echo "<script>alert('$message');</script>";
}
?>
</body>
</html>
