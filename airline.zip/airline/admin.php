<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/> <!-- Browser compatibility -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive design -->
    <title>Admin Panel</title>
    <link rel="stylesheet" href="admin.css"> <!-- Admin panel styles -->
  
    <!-- CSS for navbar -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

<!-- Logout button -->
<button type="submit" class="logout"><a href='login.php'>Log out</a></button>

<!-- Title and description -->
<div class="title">
    <h1>LuzaFly Admin Panel</h1>
    <p>Accept or Reject the status of any booking.<br>*Note that this page is only for this purpose.*</p>
</div>

<!-- Logo -->
<img src="logo.png" style="height: 100px; width:100px; margin-left: 60px; margin-top: -100px;">

<?php
    require_once('dbconnect.php');

    $sql = "SELECT * FROM Bookings";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Destination</th>
                <th>Departure Date</th>
                <th>Return Date</th>
                <th>Class</th>
                <th>Total Price ($)</th>
                <th>Action</th>
            </tr>";
        while($row = $result->fetch_assoc()) {
            $id = $row["Id"];  // Replace with actual column names
            $name = $row["first_name"] . " " . $row["last_name"];
            $destination = $row["travelling_to"];
            $departure_date = $row["departure_date"];
            $return_date = $row["return_date"];
            $total_price = $row["total_price"];
            $airline_class = $row["airline_class"];

            echo "<tr>
                <td>$id</td>
                <td>$name</td>
                <td>$destination</td>
                <td>$departure_date</td>
                <td>$return_date</td>
                <td>$airline_class</td>
                <td>$total_price</td>
                <td>
                    <div class='ahref'><a href='approved.php?id=$id'>Approved</a></div> | <a href='rejected.php?id=$id'>Rejected</a>
                </td>
            </tr>";
        }
        echo "</table>";
    } else {
        echo "No bookings found.";
    }

    $conn->close();
?>

<?php
    if (isset($_GET['message'])) {
        $message = $_GET['message'];
        echo "<script>alert('$message');</script>";
    }
?>
</body>
</html>
