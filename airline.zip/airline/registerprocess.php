<html>
<link rel="stylesheet" href="login.css">
</html>
<?php
include("dbconnect.php");
if(isset($_POST['submit'])) { 
    // Check if required fields are empty
    if(empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password'])) {
        echo "<div class='wrapper'>
        <div class='message'>
          <h3>Please fill in all required fields.</h3>
            <br>
            <a href='login.php'><button class='btn'>Go Back</button></a>
       </div></div>";
       exit; // Stop further execution
    }

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email is already registered
    $verify_query = mysqli_prepare($conn, "SELECT Email FROM Users WHERE Email = ?");
    mysqli_stmt_bind_param($verify_query, "s", $email);
    mysqli_stmt_execute($verify_query);
    mysqli_stmt_store_result($verify_query);
    
    if(mysqli_stmt_num_rows($verify_query) > 0) {
        // Email already exists, redirect back to registration page with an error message
        echo "<div class='wrapper'>
        <div class='message'>
          <h3 style='text-align: center;'>Email already exists, log in if you have an account.</h3>
            <br>
            <a href='login.php'><button class='btn'>Go Back</button></a>
       </div></div>";
       exit; // Stop further execution
    } else {
        // Email is unique, insert new user
        $insert_query = mysqli_prepare($conn, "INSERT INTO Users (Username, Email, Password) VALUES (?, ?, ?)");
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($insert_query, "sss", $username, $email, $hashed_password);
        mysqli_stmt_execute($insert_query);

        // Registration successful, redirect to login page
        echo "<div class='wrapper'>
        <div class='message'>
          <h3>Registration successful.<br>Welcome to LuzaFly!!</h3>
            <br>
            <a href='home.php'><button class='btn'>Explore our Home page</button></a>
       </div></div>";
    }
}
?>
